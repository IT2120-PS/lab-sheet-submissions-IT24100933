getwd()
setwd("C:\\Users\\gavesh\\Desktop\\IT24100933_PS_Lab_07")


#Uniform distribution
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#Exponential Distribution
pexp(2, rate = 1/3)

# Normal Distribution
# i. Probability of IQ above 130
1 - pnorm(130, mean = 100, sd = 15)

#ii. IQ score at the 95th percentile
qnorm(0.95, mean = 100, sd = 15)
